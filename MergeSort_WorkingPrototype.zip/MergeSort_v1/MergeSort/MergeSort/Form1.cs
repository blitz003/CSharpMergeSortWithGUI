﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MergeSort
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        int[] arr = new int[100];
        List<int> numbers = new List<int>();
        //int number = 0;
        //string inLine;

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("About to sort input file.");
            int number;
            StreamReader inputFile = File.OpenText("UnsortedNumbers.txt");
            int count = 0;
            while (count < 100)
            {
                number = int.Parse(inputFile.ReadLine());
                count++;

                numbers.Add(number);




            }
            arr = numbers.ToArray();

            MergeSort ob = new MergeSort();
            ob.sort(arr, 0, arr.Length - 1);



            using (StreamWriter writer = new StreamWriter("SortedList.txt"))
            {
                for (int i = 0; i < arr.Length; i++)
                {



                    writer.Write(arr[i] + "\n");
                    listBox1.Items.Add(arr[i] + "\n");
                }
                MessageBox.Show("Done.");
            }
        }
    }
}
